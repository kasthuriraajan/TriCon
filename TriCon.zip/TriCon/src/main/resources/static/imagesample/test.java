public class test{
	public static void main(String args[])
	{
		System.out.println("Hello");
		int a=896789789;
		String s=String.format("%05d", a);
		System.out.println(s);
	}
}